#define MYHEADER_H
#define VERSION_B
#define NO_TEST


//#define NOT_READY
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<windows.h>